import React from 'react';

const MotoCard = ({ moto }) => {
  return (
    <div style={styles.card}>
      <img src={moto.image} alt={moto.name} style={styles.image} />
      <h2>{moto.name}</h2>
      <p>Precio: ${moto.price}</p>
      <button style={styles.button}>Comprar</button>
    </div>
  );
};

const styles = {
  card: {
    border: '1px solid #ccc',
    borderRadius: '8px',
    padding: '16px',
    textAlign: 'center',
    width: '200px',
    margin: '10px',
  },
  image: {
    width: '100%',
    height: '150px',
    objectFit: 'cover',
  },
  button: {
    marginTop: '10px',
    padding: '10px 20px',
    backgroundColor: '#000',
    color: '#fff',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
  },
};


export default MotoCard;
