import React from 'react';
import './Footer.css'; 

const Footer = () => {
  return (
    <div className="footer-container">
        <nav>
          <ul>
            <li><a href="#">Política de Privacidad</a></li>
            <li><a href="#">Términos y Condiciones</a></li>
            <li><a href="#">Sedes</a></li>
          </ul>
        </nav>
      </div>
  )
};

export default Footer;