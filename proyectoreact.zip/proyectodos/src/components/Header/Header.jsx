import './Header.css';

const Header = () => {
  return (
    <header className='Header'>
      <img src="/image/logo.webp" alt="Logo" className='logo'/>
      <nav>
        <ul>
          <li>
            <a href="">Inicio</a>
            <a href="">Acerca de nosotros</a>
            <a href="">Servicios</a>
            <a href="">Cotizaciones</a>
            <a href="">Contacto</a>
          </li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;
