import React from 'react';
import MotoCard from '../Card/MotoCard';

const MotoList = () => {
  const motos = [
    { name: 'Yamaha YZF-R3', price: '4.990.000', image: 'https://www.yamahamotos.cl/wp-content/uploads/2022/04/R3A-2022-2-2.jpg' },
    { name: 'Kawasaki Ninja 400', price: '5.299.000', image: 'https://images.ctfassets.net/8zlbnewncp6f/2tAGR2cXs9oQTwwcObHSuj/8affc450cb86564ca05c9c76d37a8f57/kawasaki-ninja-400-abs-primer-plano.png?w=500&h=500&fit=pad&fm=webp&q=95' },
    { name: 'Honda CBR500R', price: '6.790.000', image: 'https://www.honda.es/content/dam/central/motorcycles/colour-picker/supersports/cbr500r/cbr500r_2024/r-380_grandprixred/24YM_CBR500R_Studio_GRAND_PRIX_RED_RHS.png/jcr:content/renditions/fb_r_w.webp' },
    { name: 'Harley Davidson Street Bob', price: '16.990.000', image: 'https://www.h-dsantiago.cl/img/motos2023/streetBob114/industrialYellow/1.jpg'},
    { name: 'Lifan KPR 200', price: '2.100.000', image: 'https://somosmoto.pe/images/models/gallery/lifan-kpr-200-2017-gallery-e21948.png'},
    { name: 'Keeway V302C', price: '4.890.000', image: 'https://procircuit.cl/cdn/shop/files/1_f4a7a170-2e4c-418a-b9a5-b5e65a3be7e4.jpg?v=1699995202&width=1946'},
    { name: 'Yamaha R15', price: '3.490.000.', image: 'https://images.ctfassets.net/8zlbnewncp6f/1XMbKZJ9TZf5Um6BCeLTDp/9dafb85fb0f653b3200424b15070af9d/Yamaha_New_R15_V4__1_.jpg?w=500&h=500&fit=pad&fm=webp&q=95'},
    { name: 'Honda Navi', price: '1.549.000', image: 'https://images.ctfassets.net/8zlbnewncp6f/26hoQ0bfOI2KrLCWQt3z31/e04ee725527064089e6ccb763272bd77/moto-honda-navi-primer-plano-galgo-chile.jpg?w=500&h=500&fit=pad&fm=webp&q=95'},
    { name: 'KTM RC 390 ABS', price: '5.870.000', image: 'https://images.ctfassets.net/8zlbnewncp6f/5tp9fyMEO7PANbT1iW2mrv/1891ae756e97a06e27dabed6f2cbd934/KTM_RC_390_ABS__1_.jpg?w=500&h=500&fit=pad&fm=webp&q=95'},
    { name: 'Yamaha R1', price: '23.990.000', image: 'https://images.ctfassets.net/8zlbnewncp6f/2oTXdtprqNdFWZtZ7cLTKP/0ea0c997017f2b07a9e16e4274a2ef6b/yamaha-r1-primer-plano.png?w=500&h=500&fit=pad&fm=webp&q=95'},
    { name: 'Eve Motors RE', price: '3.325.000', image: 'https://images.ctfassets.net/8zlbnewncp6f/aPHLgJLzt75MRAPrDtMr5/f09535a0707d8fda712962aee1d9cd76/RE_-_Galgo_Chile_Principal.jpg?w=500&h=500&fit=pad&fm=webp&q=95'},
    { name: 'Keeway Superlight 200', price: '2.060.000', image: 'https://images.ctfassets.net/8zlbnewncp6f/4iO0i4GT3EWNV5PsLJ5cIl/f972e46aa191bc2d106c70f3edae6610/Keeway_Superlight_200__2_.jpg?w=500&h=500&fit=pad&fm=webp&q=95'},
  ];

  return (
    <div style={styles.list}>
      {motos.map((moto, index) => (
        <MotoCard key={index} moto={moto} />
      ))}
    </div>
  );
};

const styles = {
  list: {
    display: 'flex',
    justifyContent: 'space-around',
    flexWrap: 'wrap',
  },
};

export default MotoList;
